package Lesson_03;
public class Ex000 {
   public static void main(String[] args) {
       
   }
}