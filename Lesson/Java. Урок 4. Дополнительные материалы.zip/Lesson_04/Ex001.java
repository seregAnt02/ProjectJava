package Lesson_04;

import java.util.LinkedList;

public class Ex001 {
    public static void main(String[] args) {
        LinkedList<Integer> ll = new LinkedList<Integer>();

        ll.add(1);
        ll.add(2);
        ll.add(3);
        
    }
    
}
